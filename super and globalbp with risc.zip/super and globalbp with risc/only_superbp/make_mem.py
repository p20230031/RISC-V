#!/usr/bin/env python3
import random
import sys

# ======= user parameters =======
depth        = 1024      # total ROM depth
num_branches = 50        # how many branch insns you want
# ===============================

if num_branches > depth:
    print("ERROR: num_branches cannot exceed depth", file=sys.stderr)
    sys.exit(1)

# encodings
branch_insn  = 0x00628263  # e.g. BEQ x5, x6, +8
other_insn   = 0x00510113  # e.g. ADDI x2, x2, 5
nop_insn     = 0x00000013  # NOP (only used if you want extra padding)

# derive other count so total = depth
num_others = depth - num_branches

# build the instruction list
instrs = [branch_insn] * num_branches + [other_insn] * num_others

# shuffle them
random.shuffle(instrs)

# write out exactly `depth` lines
with open("loop.mem", "w") as f:
    for insn in instrs:
        f.write(f"{insn:08x}\n")

print(f"Wrote {len(instrs)} instructions to loop.mem ("
      f"{num_branches} branches, {num_others} others)")

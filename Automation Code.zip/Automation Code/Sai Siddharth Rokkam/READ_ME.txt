Main_auto ->  parameters M,N are used to generate MxN processors, NI's and nidepacks.
		M : rows
		N : columns
	      
             Assign Destination[source_address] = [destination_address]
 
	     sample example : if communication is between router[0][0] and router[1][2] then assign destination[0][0] = 8'h12    

Auto_Mesh ->  parameters M,N,T are used to generate MxN routers with either Mesh or Torous topology
		M : rows
		N : columns
		T : Topology, 0 for Mesh and 1 for Torus.

   